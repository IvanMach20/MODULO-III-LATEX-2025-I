# diapotex
``TeX`` diapositives template

Certaines fois, mettre au point des diapositives `LaTeX` qui satisfassent nos besoins et attentes n'est pas aussi aisé. Je mets en place ce projet afin de permettre à plein de gens de collaborer et trouver facilement ce qu'ils veulent.

Pour plus d'aide, la communauté [StackOverflow](http://tex.stackexchange.com) est à votre disposition.

Vous êtes les bienvenus.
